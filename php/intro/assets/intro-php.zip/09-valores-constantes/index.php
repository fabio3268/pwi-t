<?php
require __DIR__ . '/../frame/lpwphp.php';
LPWPHPClassName("09 - Constantes e constantes mágicas");

/*
 * [ constantes ] https://php.net/manual/pt_BR/language.constants.php
 */
LPWClassSession("constantes", __LINE__);


/*
 * [ constantes mágicas ] https://php.net/manual/pt_BR/language.constants.predefined.php
 */
LPWClassSession("constantes mágicas", __LINE__);

