<?php
require __DIR__ . '/../frame/lpwphp.php';
LPWPHPClassName("08 - Trabalhando com funções");

/*
 * [ functions ] https://php.net/manual/pt_BR/language.functions.php
 */
LPWClassSession("functions", __LINE__);


/*
 * [ global access ] global $var
 */
LPWClassSession("global access", __LINE__);


/*
 * [ static arguments ] static $var
 */
LPWClassSession("static arguments", __LINE__);


